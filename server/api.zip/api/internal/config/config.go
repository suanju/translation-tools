package config

import (
	"github.com/zeromicro/go-zero/rest"
	"github.com/zeromicro/go-zero/zrpc"
)

type Config struct {
	rest.RestConf
	JWT struct {
		Secret string
		Expire int64
	}
	//rpc服务相关
	User zrpc.RpcClientConf
}
